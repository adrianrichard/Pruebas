###################
# RUN APPLICATION #
###################
from code.GUIElements import MainApplication

if __name__ == '__main__':
    root = MainApplication()
    root.mainloop()
