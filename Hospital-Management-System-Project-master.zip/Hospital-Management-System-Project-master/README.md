# Hospital-Management-System-Project
# College-Mini-Project-in-python.

This hospital management project is made using the tkinter and sqlite in python
login.py file contains the code for login page ( username and password is there in file itself)
window2.py file contains the code for menu  
PATDELSU.py file contains the code for the registtration, updation and deletion of patient records 
HMdp.py file contains the sqlite queries for database and sqlite connection 
employee_reg.py file contains code for employee registration  
BILLING.py file contains code for calculating the bill of the patient 
RooMT.py file contains code for allocating a room to the patient if he/she gets admitted. 
appointment.py file contains code for scheduling an appointment with doctor.  

This project is made in mind keeping that it can be handled by a single person handling all the database of the patient.

