# SDEV140-LG
Appointment scheduling app build for practice with Python and Tkinter.
