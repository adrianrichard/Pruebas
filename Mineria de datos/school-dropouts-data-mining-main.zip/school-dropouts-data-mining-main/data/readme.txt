`source` contains unmodified files that were extracted from the archives listed elsewhere in this repository. 

`raw` contains the relevant files that were extracted from `source` (some were renamed) and used in the data cleaning process.

`clean` contains the files after they have been cleaned.