## Tarea #4: Sistema de recomendación y evaluación de modelos

### Paper ROC 
Una introducción al análisis de curvas ROC. Tomar en cuenta solamente las primeras 5 secciones.

### Archivos csv
Referentes a la primer parte de la tarea sobre el sistema de recomendación.
