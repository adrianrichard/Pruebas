# Mineração de Dados - Eletiva Unicap

<h4 align="center"> 
	🚧  Python 🚀 Em construção...  🚧
</h4>
<hr>

Utilizando mineração de dados para analisar como questões sociais podem influenciar na evasão escolar de meninas no ensino de jovens adultos


* Variaveis análisadas

  * Infraestrutura da escola
  * Gênero do aluno
  * Região onde o aluno mora
  * Modalidade da escola (EJA ou Regular)
<br>

* Algoritimos utilizados

  * Arvore de decisão
  * K-means Clustering
  * Teste de acurácia
