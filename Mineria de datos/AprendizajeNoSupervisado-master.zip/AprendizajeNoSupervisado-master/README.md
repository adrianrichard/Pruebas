# AprendizajeNoSupervisado
Tarea #3 del curso Minería de Datos de la Universidad Central de Venezuela
