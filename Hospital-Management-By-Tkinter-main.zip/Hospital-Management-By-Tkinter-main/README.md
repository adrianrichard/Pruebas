# Hospital-Management-By-Tkinter
It was a project given to the individuals in class 12, Hospital Managament System using Python GUI(Tkinter) and CSV File. With this project i was able to manage the staff,appointment and the patients in the hospital.
