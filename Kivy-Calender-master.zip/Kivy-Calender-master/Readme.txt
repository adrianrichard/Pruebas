Kivy-Calender is a Calender built in python and kivy.

*** This project was started by Kuldeep Grewal. ***
