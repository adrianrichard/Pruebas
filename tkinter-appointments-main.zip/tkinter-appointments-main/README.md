# tkinter-appointments
1st year C.S python project with tkinter
