from tkcalendar import TKCalendar

if __name__ == "__main__":
    Tcal = TKCalendar()
    Tcal.mainloop()

