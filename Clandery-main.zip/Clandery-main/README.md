# Clandery
Clandery is an concept of an event calendar for companies who want to sort their events
They can manage their users in the company, add events, remove events and add and remove users
