# Hospital-Management
This is purely based on Python3 and Sqlite3 database and including tkinter. I tried to make a project in which we can make an appointment, update an existing appointment or delete and also in the end when everything is done we can even display it too.
